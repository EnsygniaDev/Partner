<?php
/*
*	Main File
*/


//	Global Vars
$currPage = null;

$pluginPath = str_replace('\\', '/',plugin_dir_path(__FILE__));
$pluginUrl = plugin_dir_url(__FILE__);
$isWindows = false;
if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
    $isWindows = true;
}

include_once("support/functions.php");
include_once("support/OnescanClassFile.php");

//	Loading Widget
include_once('support/OnescanWidget.php');

$onescan = new Onescan();

add_action('init','initOnescan');
//register_shutdown_function('end_fnc');

function initOnescan(){
	
	global $onescan;
	//write_log('initialising onescan...');
	
	add_action('login_enqueue_scripts',function(){
		wp_enqueue_script('jquery');
	});
	add_action('wp_enqueue_scripts',function(){
		wp_enqueue_script('jquery');
	});
	
	add_action( 'woocommerce_before_cart_totals', function(){
		global $onescan;
		global $woocommerce;
		
		$items = $woocommerce->cart->get_cart();
		//echo 'Total Amount: '.$woocommerce->cart->total;
		wp_apply_padlock(
			$onescan->get_padlock(array(
				"Action" => "ShowPadlock",
				"Page" => "CartPage",
				"PadlockType" => "Payment",
				"Container" => "Self",
				'Items' => json_encode($items),
				'Total' => $woocommerce->cart->total,
				'User' => get_current_user_id(),
				"Instruction" => "Scan the QR code<br /> to buy!."
			))
		);
	});
	add_action( 'woocommerce_login_form', function(){
		global $onescan;
		global $woocommerce;
		
		$items = $woocommerce->cart->get_cart();
		//echo 'Total Amount: '.$woocommerce->cart->total;
		wp_apply_padlock(
			$onescan->get_padlock(array(
				"Action" => "ShowPadlock",
				"Page" => "WCLoginPage",
				"PadlockType" => "Login",
				"Container" => "Self",
				"Instruction" => "Download Onescan from the store and scan the QR code to get logged in."
			))
		);
	});
	
	if(is_logout_page()){
		// Call the function that add the padlock in login Padlock
		add_action('login_form',function(){
			global $onescan;
			wp_apply_padlock(
				$onescan->get_padlock(array(
					"Action" => "ShowPadlock",
					"Page" => "LoginPage",
					"PadlockType" => "Login",
					"Container" => "#loginform",
					"Instruction" => "Download Onescan from the store and scan the QR code to get logged in."
				))
			);
		});
	}
	

	if(is_register_page()){
		// Call the function that add the padlock in login Padlock
		add_action('register_form',function(){
			global $onescan;
			wp_apply_padlock(
				$onescan->get_padlock(array(
					"Action" => "ShowPadlock",
					"Page" => "RegisterPage",
					"PadlockType" => "Register",
					"Container" => "#registerform",
					"Instruction" => "Download Onescan from the store and scan the QR code to get registered."			
				))
			);
		});
	}

	if(is_login_page()){
		// Call the function that add the padlock in login Padlock
		add_action('login_form',function(){
			global $onescan;
			wp_apply_padlock(
				$onescan->get_padlock(array(
					"Action" => "ShowPadlock",
					"Page" => "LoginPage",
					"PadlockType" => "Login",
					"Container" => "#loginform",
					"Instruction" => "Download Onescan from the store and scan the QR code to get logged in."
				))
			);
		});
	}
	if(is_session_page()){
		//write_log('Total Sessions: '.json_encode($_SESSION));
		$onescan->request_session();
		die();
	}

	if(is_callback_page()){
		//	Callback Page
		$onescan->onescan_callback();
	}
	if(is_final_page()){
		// This Function will execute after success full padlock scan
		$onescan->finalise_task();
	}
	
	//	Init Settings Page
	if ( is_admin() ){ // admin actions
	  add_action( 'admin_menu', 'onescan_plugin_menu' );
	  add_action( 'admin_init', 'register_onescansettings' );
	} else {
	  // non-admin enqueues, actions, and filters
	}
}

function register_onescansettings() { // whitelist options
  register_setting( 'onescanoption-group', 'onescan_acc_key' );
  register_setting( 'onescanoption-group', 'onescan_acc_secret' );
  register_setting( 'onescanoption-group', 'onescan_acc_discount' );
  register_setting( 'onescanoption-group', 'onescan_acc_discount_type' );
  register_setting( 'onescanoption-group', 'onescan_acc_shipping' );
  register_setting( 'onescanoption-group', 'onescan_acc_shipping_type' );
}

function onescan_plugin_menu() {
	//create new top-level menu
	add_options_page('Onescan Settings', 'Onescan', 'administrator', __FILE__, 'onescan_settings_page' , $pluginsUrl.'/images/logo.png');
}
function onescan_settings_page(){
	?>
	
<div class="wrap">
<h2>Onescan Settings</h2>

<form method="post" action="options.php">
    <?php settings_fields( 'onescanoption-group' ); ?>
    <?php do_settings_sections( 'onescanoption-group' ); ?>
    <table class="form-table">
        <tr valign="top">
        <th scope="row">Account Key</th>
        <td><input type="text" style="width: 209px;" name="onescan_acc_key" value="<?php echo esc_attr( get_option('onescan_acc_key') ); ?>" /></td>
        </tr>
         
        <tr valign="top">
        <th scope="row">Account Secret</th>
        <td><input type="text" style="width: 209px;" name="onescan_acc_secret" value="<?php echo esc_attr( get_option('onescan_acc_secret') ); ?>" /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Discount</th>
        <td>
            <input type="number" style="width: 100px;" step="0.01" name="onescan_acc_discount" value="<?php echo esc_attr( get_option('onescan_acc_discount') ); ?>" />
            <select name="onescan_acc_discount_type" style="margin-top: -2px;">
                <?php
                    if(esc_attr( get_option('onescan_acc_discount_type') ) == '0'){
                        echo '<option value="0" selected="selected">Type</option>';
                        echo '<option value="1">Rupees</option>';
                        echo '<option value="2">Percentage</option>';
                    }
                    else if(esc_attr( get_option('onescan_acc_discount_type') ) == '1'){
                        echo '<option value="0">Type</option>';
                        echo '<option value="1" selected="selected">Rupees</option>';
                        echo '<option value="2">Percentage</option>';
                    }
                    else if(esc_attr( get_option('onescan_acc_discount_type') ) == '2'){
                        echo '<option value="0">Type</option>';
                        echo '<option value="1">Rupees</option>';
                        echo '<option value="2" selected="selected">Percentage</option>';
                    }
                    else{
                        echo '<option value="0" selected="selected">Type</option>';
                        echo '<option value="1">Rupees</option>';
                        echo '<option value="2">Percentage</option>';
                    }
                ?>
            </select>
            <span>  * For woocommerce only!</span>
            <!--<input type="number" name="onescan_acc_discount_type" value="<?php echo esc_attr( get_option('onescan_acc_discount_type') ); ?>" />-->
        </td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Shipping</th>
        <td>
            <input type="number" style="width: 100px;" step="0.01" name="onescan_acc_shipping" value="<?php echo esc_attr( get_option('onescan_acc_shipping') ); ?>" />
            <select name="onescan_acc_shipping_type" style="margin-top: -2px;">
                <?php
                    if(esc_attr( get_option('onescan_acc_shipping_type') ) == '0'){
                        echo '<option value="0" selected="selected">Type</option>';
                        echo '<option value="1">Rupees</option>';
                        echo '<option value="2">Percentage</option>';
                    }
                    else if(esc_attr( get_option('onescan_acc_discount_type') ) == '1'){
                        echo '<option value="0">Type</option>';
                        echo '<option value="1" selected="selected">Rupees</option>';
                        echo '<option value="2">Percentage</option>';
                    }
                    else if(esc_attr( get_option('onescan_acc_discount_type') ) == '2'){
                        echo '<option value="0">Type</option>';
                        echo '<option value="1">Rupees</option>';
                        echo '<option value="2" selected="selected">Percentage</option>';
                    }
                    else{
                        echo '<option value="0" selected="selected">Type</option>';
                        echo '<option value="1">Rupees</option>';
                        echo '<option value="2">Percentage</option>';
                    }
                ?>
            </select>
            <span>  * For woocommerce only!</span>
        </td>
        </tr>
    </table>
    
    <?php submit_button(); ?>

</form>
</div>
	<?php
}



/**
*	Messecel functions
*/
function wp_apply_padlock($args){
	//	Some Global Variables
	global $PadlockHtml;
	global $PadlockJs;
	global $PadlockCss;
	
	$PadlockHtml = $args['html'];
	$PadlockJs = $args['js'];
	$PadlockCss = $args['css'];
	$PadlockType = $args['data']['PadlockType'];
	$Page = $args['data']['Page'];
	//print_r($args);
	//write_log('Total Sessions: '.json_encode($_SESSION));
	
	if( ($PadlockType == 'Login') || ($PadlockType == 'Register') ){
		if($Page == 'WCLoginPage'){			
			echo '<div id="onescan_cont"></div>';
		}
		add_action('login_footer',function(){
			global $PadlockHtml;
			global $PadlockJs;
			global $PadlockCss;
			
			//	echo css
			echo $PadlockCss['includable'];
			echo $PadlockCss['inline'];
			
			// echo js
			echo $PadlockJs['includable'];
			echo $PadlockJs['inline'];
		});
		add_action('wp_footer',function(){
			global $PadlockHtml;
			global $PadlockJs;
			global $PadlockCss;
			
			//	echo css
			echo $PadlockCss['includable'];
			echo $PadlockCss['inline'];
			
			// echo js
			echo $PadlockJs['includable'];
			echo $PadlockJs['inline'];
		});
	}
	if( $PadlockType == 'Payment' ){
		echo '<div id="onescan_cont"></div>';
		add_action( 'wp_footer', function(){
			global $PadlockHtml;
			global $PadlockJs;
			global $PadlockCss;
			
			//	echo css
			echo $PadlockCss['includable'];
			echo $PadlockCss['inline'];
			
			// echo js
			echo $PadlockJs['includable'];
			echo $PadlockJs['inline'];
		});
		//write_log('Total Sessions: '.json_encode($_SESSION));
	}
}

?>
