/**
*	Main Js File for Padlock
*/

	$y = jQuery;
function init_wp_padlock(){
	var t = setInterval(wp_fetch_status, 1000);
}
function wp_fetch_status(){
    //alert("fetch url");
	// Assign handlers immediately after making the request,
	// and remember the jqxhr object for this request
	var jqxhr = $y.get( "<<FINALISEURL>>", function($ydata) {
                console.log($ydata);
		var obj = jQuery.parseJSON($ydata);
		console.log("Result = " + $ydata + "\nRedirect Url: " + obj.RedirectUrl);
		if(obj.Error == "None"){
			window.location.replace(obj.RedirectUrl);
		}
		else if(obj.Error == "UserExists"){
			var r = confirm("User already exists!\n\n Please Login!");
			if (r == true) {
				window.location.replace(obj.RedirectUrl);
			} else {
			}
		}
		else if(obj.Error == "UserNotExists"){
			//alert(obj.Error);
			var r = confirm("User doesn't exists!\ so you need to Register before Login");
			if (r == true) {
				window.location.replace(obj.RedirectUrl);
			} else {
			}
		}
		else{
			//alert('None');
		}
	})
}

/*
*	for rearrange padlock
*/
$y(function() {
	
	//	Initials
	login = $y('#login');
	padlock_type = '<<padlocktype>>';
	
	container = <<container>>;
	
	onescanpadlock = $y('<<padlockcode>>');
	
	//	Customs
	primary_login_fields = $y('.primary_login_fields');
	onescan_login_fields = $y('.onescan_login_fields');
	h_saparator = $y('<div class="h_saparator"><img style="height:100%" src="<<h_saparator>>" width="100%" height="100%" /></div>');
	
	
	
	// Change the size of container
	login.css({
		"width" : "690px"
	});
	onescanpadlock.css({
		"height" : "200px"
	});
	
	//	Storing Childs to another variable
	//fields = container.html();
	if(padlock_type == 'payment'){
		fields = container.find('table').find('tbody');
		
		final_login_fields = onescanpadlock.prop('innerHTML');
		$ytr = '<tr>' + final_login_fields + '</tr>';
		fields.prepend('<tr><td colspan="2"></td></tr>');
		fields.find('tr:first > td').html(final_login_fields);
	}
	if(padlock_type == 'login'){
			//alert('yes');
			container.prepend(onescanpadlock);
			padlock_cont = $y('.padlock_cont');
			padlock_cont.prepend(h_saparator);
	}
	if(padlock_type == 'register'){
			container.prepend(onescanpadlock);
			padlock_cont = $y('.padlock_cont');
			padlock_cont.prepend(h_saparator);
	}
	
	//	Removing Old Padlock
	//onescanpadlock.remove();
});




$y(function() {
    //----- OPEN
    $y('[data-popup-open]').on('click', function(e)  {
        var targeted_popup_class = jQuery(this).attr('data-popup-open');
        $y('[data-popup="' + targeted_popup_class + '"]').fadeIn(350);
 
        e.preventDefault();
    });
 
    //----- CLOSE
    $y('[data-popup-close]').on('click', function(e)  {
        var targeted_popup_class = jQuery(this).attr('data-popup-close');
        $y('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);
 
        e.preventDefault();
    });
});
