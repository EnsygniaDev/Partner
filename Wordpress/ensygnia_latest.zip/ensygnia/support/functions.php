<?php

	/**
	*	Helper Functions File
	*	Required File
	*/
	
	// Page related functions
	
	function is_login_page(){
		if(!is_register_page()){
			if(!is_logout_page()){
				if(strpos(currentPageUrl(), wp_login_url()) !== false){
					return true;
				}
			}
		}
	}
	
	function is_logout_page(){
		if(strpos(currentPageUrl(), 'wp-login.php?loggedout=true') !== false){
			return true;
		}
	}
	
	function is_register_page(){
		if(strcmp(currentPageUrl(), wp_registration_url()) == 0){
			return true;
		}
	}
	
	function is_cart_page(){
		if ( get_the_ID () == get_option ( 'woocommerce_cart_page_id' , 0 ) ) {
				return true ;
		}
	}
	
	function is_realy_woocommerce_page () {
			if(  function_exists ( "is_woocommerce" ) && is_woocommerce()){
					return true;
			}
			$woocommerce_keys   =   array ( "woocommerce_shop_page_id" ,
											"woocommerce_terms_page_id" ,
											"woocommerce_cart_page_id" ,
											"woocommerce_checkout_page_id" ,
											"woocommerce_pay_page_id" ,
											"woocommerce_thanks_page_id" ,
											"woocommerce_myaccount_page_id" ,
											"woocommerce_edit_address_page_id" ,
											"woocommerce_view_order_page_id" ,
											"woocommerce_change_password_page_id" ,
											"woocommerce_logout_page_id" ,
											"woocommerce_lost_password_page_id" ) ;
			foreach ( $woocommerce_keys as $wc_page_id ) {
					if ( get_the_ID () == get_option ( $wc_page_id , 0 ) ) {
							return true ;
					}
			}
			return false;
	}
	
	function is_callback_page(){
		if(isset($_GET['onescan_api'])){
			if($_GET['onescan_api'] == 'callback'){
				return true;
			}
		}
	}
	function is_session_page(){
		if(isset($_GET['onescan_api'])){
			if($_GET['onescan_api'] == 'session'){
				return true;
			}
		}
	}
	
	function is_final_page(){		
		if(isset($_GET['onescan_api'])){
			if($_GET['onescan_api'] == 'final'){
				return true;
			}
		}
	}
	
	
	function currentPageUrl() {
		global $currPage;
		
		$pageURL = 'http';
		
		if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
		$pageURL .= "://";
		
		if ($_SERVER["SERVER_PORT"] != "80") {
			$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
		} else {
			$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
		}
		
		// set current Page to var_dump
		$currPage = $pageURL;
		return $currPage;
	}
	
	function write_log($str){
		global $pluginPath;
		$myfile = fopen($pluginPath."Onescan Logs.txt", "a") or die("Unable to open file!");
		fwrite($myfile, "\n". $str);
		fclose($myfile);
	}
?>