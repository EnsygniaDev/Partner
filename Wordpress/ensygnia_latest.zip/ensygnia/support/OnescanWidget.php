<?php

	/**
	*	Onescan Widget Class File
	*	Required File
	*/	
	
	
	class onescan_widget extends WP_Widget {
		
		public $onescan_logo;
		
		
		function __construct() {
			global $pluginUrl;
			parent::__construct(
				'onescan_widget',	// Base ID of your widget
				__('Onescan Widget', 'onescan_widget_domain'),  // Widget name will appear in UI
				array( 'description' => __( 'Sample widget based on WPBeginner Tutorial', 'onescan_widget_domain' ), )   // Widget description
			);
			
			$this->onescan_logo = $pluginUrl.'/images/Ensygnia-424x240.png';
		}
		
		// Creating widget front-end
		// This is where the action happens
		public function widget( $args, $instance ) {
			global $pluginUrl;
			
			$title = apply_filters( 'widget_title', $instance['title'] );
			
			// before and after widget arguments are defined by themes
			echo $args['before_widget'];
			
			if ( ! empty( $title ) )
				echo $args['before_title'] . $title . $args['after_title'];
			
			// This is where code will run and display the output
			echo __( 'Now Accepting Onescan Mobile Payment', 'onescan_widget_domain' );
			
			echo $this->get_logo_img();
			
			echo '<div class="padlock_imgs_sidebar">'.
				'<img src="'.
				$pluginUrl.'images/appstore.png'.
				'" />'.
				'<img src="'.
				$pluginUrl.'images/GooglePlay1.png'.
				'" />'.
				'</div>';
			echo $args['after_widget'];
			echo '<style>'.
				'.padlock_imgs_sidebar{'.
				'/*display: none;*/'.
				'text-align: center;'.
				'}'.
				'.padlock_imgs_sidebar IMG{'.
				'display: inline-block;'.
				'width: 45%;'.
				'margin: 5px;'.
				'}</style>';
		}
		
		// Widget Backend
		public function form( $instance ) {
			
			if ( isset( $instance[ 'title' ] ) ) {
				
				$title = $instance[ 'title' ];
				
			}
			else {
				$title = __( 'Onescan', 'onescan_widget_domain' );
			}
			
			// Widget admin form
			?>
			<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
			</p>
			<?php
		}
		// Updating widget replacing old instances with new
		public function update( $new_instance, $old_instance ) {
			$instance = array();
			$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
			return $instance;
		}
		public function get_logo_img(){
			return '<img style="margin-top:10px" src="'.$this->onescan_logo.'" width="100%" height="auto" />';
		}
	}
	
	// Register and load the widget
	function wpb_load_widget() {
		register_widget( 'onescan_widget' );
	}
	add_action( 'widgets_init', 'wpb_load_widget' );
?>