<?php

	/**
	*	Onescan Variables File
	*	Required File
	*/
	
	//	Global Vars
	global $PadlockHtml;
	global $PadlockJs;
	global $PadlockCss;
	global $PluginPath;
	global $PluginUrl;
?>