<?php

/**
 * 	Onescan Tasks Class File
 * 	Required File
 */
class OnescanTaskManager {

    // Database Related
    public $WPDB;
    public $TableName;
    public $TableId;
    //	User Related
    public $TaskTitle;
    public $TaskType;
    public $UserToken;
    //Other
    public $TaskAdded;
    public $NewSessionIdGenerated;
    public $TaskExistingTime = 5;
    public $TaskLifeSpan = 60; // max time that a task can rly
    public $SessionStr = 'TempTaskSessionId12';

    function __construct() {
        global $wpdb;
        $this->WPDB = $wpdb;
        $this->TableName = $wpdb->prefix . 'onescan_tasks';
        session_start();

        $this->TaskAdded = false;
        $this->NewSessionIdGenerated = false;

        //	First of all Register Init Onescan Tasks
        $this->init_onescan_tasks();
        //$this->deleteWasteTasks();
    }

    function getNewSessionId() {
        if (!$this->NewSessionIdGenerated) {
            $_SESSION[$this->SessionStr] = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 35)), 0, 35);

            $this->NewSessionIdGenerated = true;

            return $_SESSION[$this->SessionStr];
        } else {
            return false;
        }
    }

    function getCurrentSessionId() {
        //write_log('Session in getCurrentSessionId: ' . json_encode($_SESSION));
        return $_SESSION[$this->SessionStr];
    }

    function getCurrentTask() {
        $TempS = $this->getCurrentSessionId();
        //write_log('Sessions in getCurrentTask: ' . json_encode($_SESSION));
        $lastTask = null;

        $query = "SELECT * FROM " . $this->TableName . " WHERE SessionId ='" . $TempS . "'";
        //echo '<br /> Query: '.$query;

        $alltasks = $this->WPDB->get_results($this->WPDB->prepare($query, APP_POST_TYPE));

        foreach ($alltasks as $task) {
            if (strcmp($TempS, $task->SessionId) == 0) {
                $lastTask = $task;
                break;
            }
            write_log("All Tasks in getCurrentTask: " . print_r($task));
        }

        return $lastTask;
    }

    function addTask($task) {
        // Fields
        $Type = $task['Type'];
        $Title = $task['Title'];
        $Items = (isset($task['Items']) ? $task['Items'] : '');
        $Total = (isset($task['Total']) ? $task['Total'] : '');
        $User = (isset($task['User']) ? $task['User'] : '');

        if (!$this->TaskAdded) {
            // Initialise a new Session Task
            $SessionId = $this->getNewSessionId();
            //write_log('Session id: '.$SessionId);
            $this->WPDB->insert($this->TableName, array(
                'Type' => $Type,
                'Title' => $Title,
                'Created' => current_time('mysql'),
                'Modified' => current_time('mysql'),
                'SessionId' => $SessionId,
                'Items' => $Items,
                'Total' => $Total,
                'User' => $User
            ));
            //echo 'Task Added! Session id: '.$SessionId;
            $this->TaskAdded = true;
            $this->TableId = $this->WPDB->insert_id;
        } else {
            die();
        }
        //write_log('Current Session in OnescanTask: '.$_SESSION[$this->SessionStr]);

        return $this->TableId;
    }

    function updateTask($args) {
        $CurrentTask = null;
        $TaskId = $args['Id'];
        unset($args['Id']);
        //echo $args['OrderId'];
        //echo $TaskId;
        //	Conditional Checkings....
        if (($TaskId == 'Current') || ($TaskId == 'current')) {
            $CurrentTask = $this->getCurrentTask();
        }

        if (!isset($args['Status']) || ($args['Status'] == '')) {
            $args['Status'] = 'Pending';
        }

        if (!isset($args['Error']) || ($args['Error'] == '')) {
            $args['Error'] = 'None';
        }

        $affectedRow = $this->WPDB->update($this->TableName, $args, array('id' => intval($TaskId))) . '<br />';
        //print_r($affectedRow);
        if ($affectedRow != 0) {
            return true;
        } else {
            return false;
        }
    }

    function getTaskById($id) {
        //echo 'passed id: '.$id;
        $query = "SELECT * FROM " . $this->TableName . " WHERE Id ='" . $id . "'";

        $result = $this->WPDB->get_results($this->WPDB->prepare($query, APP_POST_TYPE));

        //echo json_encode($result);
        return $result[0];
    }

    function deleteTask($id) {
        $affectedRow = $this->WPDB->delete($this->TableName, array('ID' => $id));
        if ($affectedRow != 0) {
            return true;
        } else {
            return false;
        }
    }

    function deleteWasteTasks() {
        $query = "SELECT id, Modified FROM " . $this->TableName;
        $CurrentTime = new DateTime();

        $result = $this->WPDB->get_results($this->WPDB->prepare($query, APP_POST_TYPE));

        foreach ($result as $task) {
            $ModifiedTime = new DateTime($CurrentTask->Modified);
            $TimeDifference = $ModifiedTime->diff($CurrentTime);
            //echo $interval->format('%s days');

            if (intval($TimeDifference->format('%s')) > $this->TaskLifeSpan) {
                // delete the task
            } else {
                //echo 'Time Difference: '.intval($TimeDifference->format('%s'))."<br />";
                //echo 'Time Remainging: '.($this->TaskExistingTime - intval($TimeDifference->format('%s')))."<br />";
            }
        }
    }

    function init_onescan_tasks() {
        // if creation
        $table_name = $this->TableName;

        if ($this->WPDB->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            //table not in database. Create new table
            $charset_collate = $this->WPDB->get_charset_collate();

            $sql = "CREATE TABLE $table_name (
					  id mediumint(9) NOT NULL AUTO_INCREMENT,
					  Type text NOT NULL,
					  Title text NOT NULL,
					  Created datetime NOT NULL,
					  Modified datetime NOT NULL,
					  SessionId text NOT NULL,
					  UserToken text NOT NULL,
					  Status text NOT NULL,
					  Error text,
					  RedirectUrl text NOT NULL,
					  OrderId text,
					  User text NOT NULL,
					  Items text NOT NULL,
					  ShippingAmount text,
					  Discount text,
					  Total text NOT NULL,
					  UNIQUE KEY id (id)
				 ) $charset_collate;";
            require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
            dbDelta($sql);

            //addd coupon
            $coupon_code = 'ONESCAN38'; // Code - perhaps generate this from the user ID + the order ID
            $amount = '10'; // Amount
            $discount_type = 'percent'; // Type: fixed_cart, percent, fixed_product, percent_product

            $coupon = array(
                'post_title' => $coupon_code,
                'post_content' => '',
                'post_status' => 'publish',
                'post_author' => 1,
                'post_type' => 'shop_coupon'
            );

            $new_coupon_id = wp_insert_post($coupon);

// Add meta
            update_post_meta($new_coupon_id, 'discount_type', $discount_type);
            update_post_meta($new_coupon_id, 'coupon_amount', $amount);
            update_post_meta($new_coupon_id, 'individual_use', 'no');
            update_post_meta($new_coupon_id, 'product_ids', '');
            update_post_meta($new_coupon_id, 'exclude_product_ids', '');
            update_post_meta($new_coupon_id, 'usage_limit', '1');
            update_post_meta($new_coupon_id, 'expiry_date', '');
            update_post_meta($new_coupon_id, 'apply_before_tax', 'yes');
            update_post_meta($new_coupon_id, 'free_shipping', 'no');
        } else {
            
        }
    }

}

?>