<?php

/**
 * 	Onescan Class File
 * 	Required File
 */
class Onescan {

    public $AccountKey;
    public $AccountSecret;
    public $CallbackUrl;
    public $RequestSessionUrl;
    public $ServerUrl;
    public $BaseUrl;
    public $PollTarget;
    public $OnescanTaskManager;
    public $UserSessionTempId;
    public $RedirectUrl;
    public $CurrentTask;
    public $OnescanPadlockStatusUrl;
    public $CurrentPageUrl;
    public $PadlockType;
    public $Result;
    public $TaskId;
    public $padlock_type = ''; // Possible Types: Login, Register, Payment

    public function __construct() {
        $this->BaseUrl = get_site_url() . '/';
    }

    public function get_padlock($args) {
        global $pluginUrl;
        //	Padlock instruction n Buttons			
        $extras['instruct'] = $args['Instruction'];
        $extras['popupbutton'] = $this->print_popup_button(
                '<div class="img_cont">' .
                '<img src="' . $pluginUrl . 'images/onescan_instruction_img.png" />' .
                '</div>'
        );

        // Create task
        $y = new OnescanTaskManager();
        $extras['task'] = $y->addTask(array(
            'Type' => $args['PadlockType'],
            'Title' => $args['PadlockType'] . ' Task',
            'TaskType' => 'Payment',
            'Items' => $args['Items'],
            'Total' => $args['Total'],
            'User' => $args['User']
        ));

        $args['task'] = $extras['task'];

        //$task = $y->getCurrentTask();
        //write_log('Current Task in OnescanClassFile: ' . json_encode($task));
        //write_log('Session id: ' . $y->getCurrentSessionId());
        //write_log('Total Sessions: ' . json_encode($_SESSION));
        //	create padlock result
        $result['html'] = $this->get_padlock_html($extras); // Return String
        $result['css'] = $this->get_padlock_css($args);  // Return Array.... Includable, Inline
        $result['js'] = $this->get_padlock_js($result['html'], $args);  // Return Array.... Includable, Inline
        $result['data'] = $args;

        return $result;
    }

    public function print_popup_button($html) {

        //	Final String
        $newHtml = '<input class="button" data-popup-open="popup-1" type="button" value="Know More" name="need_help" />' .
                // Field
                '<div class="popup" data-popup="popup-1">' .
                '<div class="popup-inner">' .
                // echo HTML
                $html .
                '<p><a data-popup-close="popup-1" href="#">Close</a></p>' .
                '<a class="popup-close" data-popup-close="popup-1" href="#">x</a>' .
                '</div>' .
                '</div>';

        return $newHtml;
    }

    public function get_padlock_html($args) {
        global $pluginUrl;
        $this->init_onescan_credentials();

        $result = '';

        //	inits the vars
        $SessionUrl = $this->RequestSessionUrl
                . '&act=' . $this->PadlockType;
        $instruct = $args['instruct'];
        $popupbutton = $args['popupbutton'];
        $task = $args['task'];

        //return $result;
        return '<div class="padlock_cont">' .
                '<div id="onescanPadlock_1" ' .
                'class="onescanpadlock" ' .
                'data-sessionurl="' . $this->RequestSessionUrl . '&ti=' . $task . '" ' .
                'data-postconfirm="wp_fetch_status();" ' .
                'data-postfailed="alert(&#39;Process Failed&#39;);" ' .
                'data-buttononly="true"' .
                'data-nonescan="true" ' .
                'data-polltarget="' . $this->PollTarget . '"> ' .
                '</div>' .
                //	Instruct
                '<div class="onescaninstructions"><div class="instructions_cont">' .
                $instruct . '<br />' .
                $popupbutton .
                '</div></div>' .
                '<div class="padlock_imgs">' .
                '<img style="float:left;" src="' .
                $pluginUrl . 'images/appstore.png' .
                '" />' .
                '<img style="float:right;" src="' .
                $pluginUrl . 'images/GooglePlay1.png' .
                '" />' .
                '</div>' .
                '</div>';
    }

    public function get_padlock_css($args) {
        $result = array();
        global $pluginUrl;
        global $pluginPath;

        $vMain = file_get_contents($pluginPath . 'client/vMain.css');
        $vCustom = file_get_contents($pluginPath . 'client/vCustom.css');
        $hSaparator = $pluginUrl . 'images/h_saparator.png';

        $result['includable'] = '<style>' . str_replace("<<h_saparator>>", $hSaparator, $vMain) . '</style>';
        $result['inline'] = '<style>';

        if ($args['PadlockType'] == 'Login') {
            //	Styles for Login Padlock

            $pos1 = strpos($vCustom, '/*** Login Part Start ***/');
            $pos2 = strpos($vCustom, 'End ***/');
            $css = substr($vCustom, $pos1, $pos2);

            $result['inline'] = $result['inline'] . $css;
        }
        if ($args['Page'] == 'WCLoginPage') {

            $css = file_get_contents($pluginPath . 'client/vWCLogin.css');

            $result['inline'] = $result['inline'] . $css;
        }

        if ($args['PadlockType'] == 'Payment') {

            $css = file_get_contents($pluginPath . 'client/vPayment.css');

            $result['inline'] = $result['inline'] . $css;
        }

        if ($args['PadlockType'] == 'Register') {

            $css = file_get_contents($pluginPath . 'client/vRegister.css');

            $result['inline'] = $result['inline'] . $css;
        }


        $result['inline'] = $result['inline'] . '</style>';

        return $result;
    }

    public function get_padlock_js($padlockcode, $args) {
        $result = array();

        global $pluginPath;
        global $pluginUrl;
        $FinaliseUrl = get_site_url() . '/?onescan_api=final&ti='.$args['task'];
        if ($args['Container'] == 'Self') {
            $container = '$y("#onescan_cont").parent()';
        } else {
            $container = '$y("' . $args['Container'] . '")';
        }

        //	Custom js
        $custom_js = file_get_contents($pluginPath . 'client/main.js');
        $hSaparator = $pluginUrl . 'images/h_saparator.png';
        $rPattern = array(
            "toRemove" => array('<<FINALISEURL>>', '<<h_saparator>>', '<<padlockcode>>', '<<padlocktype>>', '<<container>>'),
            "toApply" => array($FinaliseUrl, $hSaparator, $padlockcode, strtolower($args['PadlockType']), $container),
        );
        //write_log("".$args['task']);

        $result['inline'] = '';
        $result['includable'] = '';

        $result['inline'] = $result['inline'] . '<script type="text/javascript">';
        $result['inline'] = $result['inline'] . str_replace($rPattern['toRemove'], $rPattern['toApply'], $custom_js);
        $result['inline'] = $result['inline'] . '</script>';


        $result['includable'] = $result['includable'] . '<script type="text/javascript" src="//onescanresources.ensygnia.net/onescan/latest/scripts/onescan.js"></script>';

        return $result;
    }

    public function finalise_task() {
        //	getting the task
        $y = new OnescanTaskManager();
        $task = $y->getTaskById($_GET['ti']);

        if (isset($task->id)) {
            $response = null;

            if (!isset($response)) {
                $response = new stdClass;
            }
            $err_message = '';

            $task_type = $task->Type;
            $response->Error = $task->Error;

            if ($task_type == 'Payment') {
                $response->OrderId = $task->OrderId;
                $response->RedirectUrl = $task->RedirectUrl;
                $user = get_users(array('meta_key' => 'userToken', 'meta_value' => $task->UserToken));
                if (isset($user[0]->ID)) {
                    $this->login_user($user[0]->ID, $user[0]->data->user_login);
                }
            } elseif (($task_type == 'Login') || ($task_type == 'Register')) {
                $userToken = $task->UserToken;

                if (isset($response->Error) & ($response->Error != 'None')) {
                    $response->RedirectUrl = $task->RedirectUrl;
                } elseif (isset($userToken) & ($userToken != '')) {
                    $user = get_users(array('meta_key' => 'userToken', 'meta_value' => $userToken));
                    if (isset($user[0]->ID)) {
                        $this->login_user($user[0]->ID, $user[0]->data->user_login);
                    }
                    if ($user[0]->ID == get_current_user_id()) {
                        $myaccount_page_id = get_option('woocommerce_myaccount_page_id');
                        if ($myaccount_page_id) {
                            $myaccount_page_url = get_permalink($myaccount_page_id);
                        }
                        $response->RedirectUrl = $myaccount_page_url;
                    }
                    if (!isset($response->RedirectUrl)) {
                        $response->RedirectUrl = get_site_url();
                    }
                }
            }

            // Getting User Based on Token Task
            echo json_encode($response);
        } else {
            
        }
        die();
    }

    function login_user($userId, $userName) {
        wp_clear_auth_cookie();
        wp_set_current_user($userId, $userName);
        do_action('wp_login', $userName);
        wp_set_auth_cookie($userId, true);
    }

    public function init_onescan_credentials() {

        //	Initialize the Padlock Vars
        $this->AccountKey = esc_attr(get_option('onescan_acc_key'));
        $this->AccountSecret = esc_attr(get_option('onescan_acc_secret'));
        $this->ServerUrl = 'https://liveservice.ensygnia.net/api/partnergateway/2/RequestOnescanSession';
        $this->RequestSessionUrl = $this->BaseUrl . '?onescan_api=session';
        $this->PollTarget = 'https://liveservice.ensygnia.net/api/PartnerGateway/1/CheckOnescanSessionStatus';
        $this->RedirectUrl = $this->BaseUrl;
        $this->OnescanPadlockStatusUrl = $this->BaseUrl . '?onescan_api=checkrequeststatus';
    }

    function request_session() {
        //	getting the task
        global $isWindows;

        $y = new OnescanTaskManager();
        $task = $y->getTaskById($_GET['ti']);


        global $pluginPath;
        $this->init_onescan_credentials();
        $this->CallbackUrl = get_site_url() . '/?onescan_api=callback&ti=' . $task->id;


        $onescanRequest = NULL;
        if (!isset($onescanRequest)) {
            $onescanRequest = new stdClass;
        }
        $onescanRequest->ProcessType = "Login";
        $onescanRequest->MessageType = "StartLogin";
        $onescanRequest->LoginPayload = $this->createLoginRequest($task->Type);

        // Build the Request Onescan Session payload
        if ($task->Type == "Login") {
            // Login Processes:
            $onescanRequest->ProcessType = "Login";
            $onescanRequest->MessageType = "StartLogin";
            $onescanRequest->LoginPayload = $this->createLoginRequest($task->Type);
        }
        if ($task->Type == "Register") {
            // Registeration Process
            $onescanRequest->ProcessType = "Login";
            $onescanRequest->MessageType = "Login";
            $onescanRequest->LoginPayload = $this->createLoginRequest($task->Type);
        } elseif ($task->Type == "Payment") {
            // Payment Process
            $onescanRequest->ProcessType = "Payment";
            $onescanRequest->MessageType = "StartPayment";
        } elseif ($task->Type == "WebContent") {
            // WebContent Processes
            $onescanRequest->ProcessType = "WebContent";
            $onescanRequest->MessageType = "WebContent";
        }

        $onescanRequest->SessionData = $task->id;
        $onescanRequest->Version = 2;

        if (!isset($onescanRequest->MetaData)) {
            $onescanRequest->MetaData = new stdClass;
        }
        $onescanRequest->MetaData->EndpointURL = $this->CallbackUrl;
        write_log('Callback Url: ' . json_encode($onescanRequest->MetaData->EndpointURL));

        // JSon Encode
        $onescanRequestMessage = json_encode($onescanRequest);

        // Sign the header
        $hmac = $this->hashit($onescanRequestMessage, $this->AccountSecret);
        $header = array(
            "content-type: application/json",
            "x-onescan-account: " . $this->AccountKey,
            "x-onescan-signature: " . $hmac
        );
        $uri = curl_init($this->ServerUrl);
        curl_setopt($uri, CURLOPT_HTTPHEADER, $header);
        curl_setopt($uri, CURLOPT_POST, true);
        curl_setopt($uri, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($uri, CURLOPT_POSTFIELDS, $onescanRequestMessage);
        //	For windows curl is needed
        if ($isWindows) {
            curl_setopt($uri, CURLOPT_CAINFO, $pluginPath . "/curl/curl-ca-bundle.crt");
        }

        try {
            $response = curl_exec($uri);
            if (curl_errno($uri)) {
                throw new Exception("HTTP Error " . curl_errno($uri) . ". " . curl_error($uri));
            }
            curl_close($uri);
        } catch (Exception $e) {
            curl_close($uri);
            file_put_contents("php://stdout", $hmac . "ffff\n");
            throw $e;
        }

        echo $response;

        die();
    }

    function createLoginRequest($type) {
        $loginPayload = NULL;
        if (!isset($loginPayload)) {
            $loginPayload = new stdClass;
        }
        $loginPayload->FriendlyName = get_bloginfo('name');
        $loginPayload->SiteIdentifier = "76fufg5jhg";

        if ($type == "Register") {
            $loginPayload->LoginMode = "Register";
        } elseif ($type == "Login") {
            $loginPayload->LoginMode = "UserToken";
        } else {
            $loginPayload->LoginMode = "UserToken";
        }

        $loginPayload->Profiles = [ "basic"];
        return $loginPayload;
    }

    function onescan_callback() {
        //	getting the task
        $y = new OnescanTaskManager();
        $this->TaskId = $_GET['ti'];

        //	Init Credentials needed for callback
        $this->init_onescan_credentials();

        // Read the contents of the post
        global $jsonContent;
        write_log("Jsoncontent: " . $jsonContent);

        //  custom demo message
        if ($jsonContent == '') {
            //  login message
            $jsonContent = '{"Version":2,"UserToken":{"UserToken":"5D7519F9988D185CAF4FFAB9397589877D3784A5B8F996CF8AEFD02B4A0D0C54"},"LoginPayload":{"SiteIdentifier":"76fufg5jhg","FriendlyName":"Ensygnia Test","LoginMode":"UserToken","Profiles":["basic"]},"MessageType":"StartLogin","ProcessType":"Login","PlayMode":true,"SessionData":"8","Success":true}';

            // another
            //$jsonContent = '{"Version":2,"PurchasePayload":{"MerchantName":"Ensygnia Test","MerchantTransactionId":"20160807105215-102","PurchaseDescription":"Order","ProductAmount":71800,"Tax":0,"TaxExempt":false,"PaymentAmount":71800,"Currency":"INR","RequiresDeliveryAddress":true,"Requires":{"DeliveryOptions":true,"Surcharges":false,"OrderConditions":false},"UserSpecifiedAmountType":"None","AllowDiscretionaryAmount":false,"SupportQuantities":false,"MaxQuantityType":"AcrossAllVariants","ProcessType":"purchase"},"PurchaseContext":{"DeliveryAddress":{"AddressId":"00000000-0000-0000-0000-000000000000","Description":"Arjunganj","AddressLine1":"Vill & Post Arjunganj,","AddressLine2":"Galla Mandi, Sultanpur Road","Town":"Lucknow","County":"India","Postcode":"226002","IsActive":false,"UserId":"00000000-0000-0000-0000-000000000000","Country":"India","CountryCode":"IN"},"PaymentMethod":{"PaymentMethodType":"OnescanPlay","CardInformation":{"CardType":"Credit","Corporate":false,"PaymentSystemCode":"ONESCAN","CountryCode":"GB","PaymentSystemName":"Onescan test card","Issuer":"EnsygniaTest","VaultID":0}}},"UserToken":{"UserToken":"5D7519F9988D185CAF4FFAB9397589877D3784A5B8F996CF8AEFD02B4A0D0C54"},"MessageType":"AdditionalCharges","ProcessType":"Payment","PlayMode":true,"SessionData":"45","Success":true}';
        }

        # Parse the payload json into an object
        $onescanMessage = json_decode($jsonContent);

        write_log('Onescan Message: ' . json_encode($onescanMessage));
        write_log('Message Type: ' . $onescanMessage->MessageType);

        // the responseMessage to be returned to Onescan
        $responseMessage = NULL;

        switch ($onescanMessage->MessageType) {
            case 'StartPayment':
                $responseMessage = $this->startPayment($onescanMessage);
                break;

            case 'AdditionalCharges':
                $responseMessage = $this->additionalCharges($onescanMessage);
                break;

            case "PaymentTaken":
                $responseMessage = $this->purchaseDone($onescanMessage);
                break;

            case 'PaymentConfirmed':
                $responseMessage = $this->purchaseDone($onescanMessage);
                break;

            case 'PaymentCaptured':
                $responseMessage = $this->createSuccessMessage($onescanMessage);
                break;

            case "PaymentFailed":
                $responseMessage = $this->createSuccessMessage($onescanMessage);
                break;

            case "PaymentCancelled":
                $responseMessage = $this->createSuccessMessage($onescanMessage);
                break;

            // Web Content Process
            case "WebContent":
                $responseMessage = $this->createWebContentMessage($onescanMessage);
                break;

            case "StartLogin":
                $responseMessage = $this->createStartLoginMessage($onescanMessage, $y);
                break;

            case "Login":
                $responseMessage = $this->createLoginMessage($onescanMessage, $y);
                break;

            default:
        }
        $response = json_encode($responseMessage);

        // Create and sign the headers.
        $hmac = $this->hashit($response, $this->AccountSecret);

        header("Content-Type: application/json");
        header("x-onescan-account: " . $this->AccountKey);
        header("x-onescan-signature: " . $hmac);

        echo $response;

        die();
    }

    function registerUser($args) {
        //	Register User
        $firstName = $args['FirstName'];
        $lastName = $args['LastName'];
        $userEmail = $args['UserEmail'];
        $userToken = $args['UserToken'];
        $deliveryInfo = $args['DeliveryInfo'];

        //	Create a Address if Available
        $address = array(
            'first_name' => $firstName,
            'last_name' => $lastName,
            'company' => '',
            'email' => $userEmail,
            'phone' => '',
            'address_1' => $deliveryInfo->AddressLine1,
            'address_2' => $deliveryInfo->AddressLine2,
            'city' => $deliveryInfo->Town,
            'state' => $deliveryInfo->State,
            'postcode' => $deliveryInfo->Postcode,
            'country' => $deliveryInfo->CountryCode
        );

        $data = array(
            'billing_address' => $address,
            'Shipping_address' => $address
        );

        $userId = strtolower($firstName . $lastName) . rand(10, 100);
        $result = null;

        //	Check if User Already Exists
        $userExists = username_exists($userId);
        while (username_exists($userId)) {
            $userId = strtolower($firstName . $lastName) . rand(10, 100);
            $userExists = username_exists($userId);
        }

        if (!$userExists and email_exists($userEmail) == false) {
            $random_password = wp_generate_password($length = 12, $include_standard_special_chars = false);
            $user_id = wp_create_user($userId, $random_password, $userEmail);
            add_user_meta($user_id, 'userToken', $userToken);
            update_user_meta($user_id, 'first_name', $firstName);
            update_user_meta($user_id, 'last_name', $lastName);

            //	For Billing Address
            foreach ($address as $key => $value) {
                update_user_meta($user_id, "billing_" . $key, $value);
            }

            //	For Shipping Address
            foreach ($address as $key => $value) {
                update_user_meta($user_id, "shipping_" . $key, $value);
            }

            // update the role for the user
            $yUser = new WP_User($user_id);
            $yUser->remove_role('subscriber');
            $yUser->add_role('customer');

            //	Success
            $result = $user_id;
        } else {
            // 'user already exists'
            $result = false;
        }

        return $result;
    }

    function startPayment($onescanMessage) {
        $responseMessage = NULL;
        $purchasePayload = NULL;
        //	getting the task
        $y = new OnescanTaskManager();

        $userToken = $onescanMessage->UserToken->UserToken;

        if (!isset($reponseMessage)) {
            $responseMessage = new stdClass;
        }
        if (!isset($purchasePayload)) {
            $purchasePayload = new stdClass;
        }
        $purchasePayload->MerchantName = get_bloginfo('name');

        $purchasePayload->Currency = get_woocommerce_currency();
        //write_log("Selected Currency: ".get_woocommerce_currency());

        $purchasePayload->RequiresDeliveryAddress = true;

        $purchasePayload->ImageData = "http://www.ensygnia.com/wp-content/uploads/onescan-square-image.png";


        $y->updateTask(array(
            'Id' => $this->TaskId,
            'UserToken' => $userToken
        ));

        $lastTask = $y->getTaskById($this->TaskId);
        //write_log('Task after updateing order id: ' . json_encode($lastTask));

        $totalAmount = $lastTask->Total;
        $items = json_decode($lastTask->Items);

        // build order data
        $order = wc_create_order();
        foreach ($items as $product) :
            $order->add_product(get_product($product->product_id), $product->quantity);
        endforeach;

        $shipping_amount = 0;

        // Calculating Shipping
        $shipping_amount = $this->getShippingCharge($totalAmount);

        $order->add_shipping(new WC_Shipping_Rate('onescan_shipping', 'Onescan shipping', $shipping_amount, $shipping_taxes, 'flate_rate'));
        //$order->add_coupon( 'onescan_discount', 50 );
        //$order->add_coupon('ONESCAN38', '10', '2');

        $order->calculate_totals();
        $payment_amount = $order->get_total();
        write_log($payment_amount);

        update_post_meta($order->id, '_payment_method', 'Onescan');
        update_post_meta($order->id, '_payment_method_title', 'Onescan');


        $order_id = $order->id;


        $purchasePayload->MerchantTransactionId = str_replace('.', '', date("Y.m.d") . date("h.i.s")) . "-" . $order_id;

        $y->updateTask(array(
            'Id' => $this->TaskId,
            'OrderId' => $order_id,
            'ShippingAmount' => $shipping_amount
        ));

        $purchasePayload->PurchaseDescription = "Order";
        $purchasePayload->ProductAmount = $totalAmount;
        $purchasePayload->Tax = 0.00;
        $purchasePayload->PaymentAmount = $payment_amount;

        $requires = new stdClass();
        $requires->DeliveryOptions = true;
        $purchasePayload->Requires = $requires;

        $responseMessage->PurchasePayload = $purchasePayload;

        return $responseMessage;
    }

    function getShippingCharge($amount) {
        $shipping_amount = 0;
        $amount1 = get_option('onescan_acc_shipping');
        $type = get_option('onescan_acc_shipping_type');

        if ($type == '1') {
            $shipping_amount = intval($amount1);
        } else if ($type == '2') {
            //$temp = ($amount*$amount1)/100;
            $shipping_amount = (float) (($amount * $amount1) / 100);
        }

        return $shipping_amount;
    }

    function getDiscount($amount) {
        $discount = 0;
        $amount1 = (float) get_option('onescan_acc_discount');
        $type = get_option('onescan_acc_discount_type');

        if ($type == '1') {
            $discounted_price = $amount1;
        } else if ($type == '2') {
            //$temp = ($amount*$amount1)/100;
            $temp = (float) (($amount * $amount1) / 100);
            $discounted_price = $temp;
        }

        return $discount;
    }

    function getDiscountedPrice($amount) {
        $discounted_price = 0;
        $amount1 = (float) get_option('onescan_acc_discount');
        $type = get_option('onescan_acc_discount_type');

        if ($type == '1') {
            $discounted_price = (float) $amount - $amount1;
        } else if ($type == '2') {
            //$temp = ($amount*$amount1)/100;
            $temp = (float) (($amount * $amount1) / 100);
            $discounted_price = (float) $amount - $temp;
        }

        return $discounted_price;
    }

    function addPaymentVariants($onescanMessage) {

        $paymentVariants = NULL;
        if (!isset($paymentVariants)) {
            $paymentVariants = new stdClass;
        }
        $paymentVariants->VariantSelectionType = "MultipleChoice";
        $products = $onescanMessage->MetaData->OrderItems;

        $paymentVariants->Variants = array();


        $order = new WC_Order($_GET['order_id']);

        $orders = $order->get_items(); //to get info about product


        foreach ($orders as $product) {
            $variant3 = NULL;
            if (!isset($variant3)) {
                $variant3 = new stdClass;
            }
            $variant3->Id = $product['product_id'];
            $variant3->PurchaseDescription = $product['name'];
            $variant3->Tax = 0;
            $variant3->ProductAmount = intval($product['line_subtotal']);
            $variant3->PaymentAmount = intval($product['line_subtotal']);
            $variant3->SelectByDefault = true;
            $variant3->ImageData = "http://www.ensygnia.com/wp-content/uploads/onescan-square-image.png";
            array_push($paymentVariants->Variants, $variant3);
        }
        return $paymentVariants;
    }

    function addMerchantFields($onescanMessage) {
        $fieldGroup1 = NULL;
        if (!isset($fieldGroup1)) {
            $fieldGroup1 = new stdClass;
        }
        $fieldGroup1->GroupHeading = "Group 1";
        $fieldGroup1->IsMandatory = true;
        $fieldGroup1->Code = "G1";
        // GroupType can be Informational | ExclusiveChoice
        $fieldGroup1->GroupType = "ExclusiveChoice";
        // Only applies when used with Payment Variants
        $fieldGroup1->AppliesToEachItem = true;

        $field1 = NULL;
        if (!isset($field1)) {
            $field1 = new stdClass;
        }

        $field1->Label = "Option 1";
        $field1->Code = "F1";
        $field1->PriceDelta = 10.0;
        $field1->TaxDelta = 2.0;
        $field1->SelectByDefault = true;

        $field2 = NULL;
        if (!isset($field2)) {
            $field2 = new stdClass;
        }
        $field2->Label = "Option 2";
        $field2->Code = "F2";
        $field2->PriceDelta = 20.0;
        $field1->TaxDelta = 4.0;
        $field2->SelectByDefault = false;
        $fieldGroup1->Fields = [
            $field1,
            $field2
        ];

        $merchantFields = NULL;
        if (!isset($merchantFields)) {
            $merchantFields = new stdClass;
        }
        $merchantFields->FieldGroups = [ $fieldGroup1];
        return $merchantFields;
    }

    function additionalCharges($onescanMessage) {
        //  initiating task
        $y = new OnescanTaskManager();

        $lastTask = $y->getTaskById($this->TaskId);
        //write_log('Last Taskin additional charges: '.json_encode($lastTask));

        $shipping_amount = $lastTask->ShippingAmount;

        $deliveryOption1 = NULL;
        $deliveryOption1->Code = "Standara Shipping";
        $deliveryOption1->Description = "Standard Shipping";
        $deliveryOption1->IsDefault = true;
        $deliveryOption1->Label = "Standard Shipping";

        $charge1 = NULL;
        $charge1->BaseAmount = $shipping_amount;
        $charge1->Tax = 0.0;
        $charge1->TotalAmount = $shipping_amount;
        $deliveryOption1->Charge = $charge1;

        $additionalCharges = NULL;
        $additionalCharges->DeliveryOptions[0] = $deliveryOption1;

        $deliveryOption2 = NULL;
        $deliveryOption2->Code = "SECOND";
        $deliveryOption2->Description = "Royal Mail Second Class";
        $deliveryOption2->IsDefault = false;
        $deliveryOption2->Label = "Second class";

        $charge2 = NULL;
        $charge2->BaseAmount = 1.99;
        $charge2->Tax = 0.0;
        $charge2->TotalAmount = 1.99;
        $deliveryOption2->Charge = $charge2;

        //$additionalCharges->DeliveryOptions[1] = $deliveryOption2;
        // Surcharges
        $paymentMethodCharge = NULL;
        $paymentMethodCharge->Code = "PLAY";
        $paymentMethodCharge->Description = "This attracts a surcharge";

        $charge3 = NULL;
        $charge3->BaseAmount = $shipping_amount;
        $charge3->Tax = 0.0;
        $charge3->TotalAmount = $shipping_amount;
        $paymentMethodCharge->Charge = $charge3;

        //$additionalCharges->PaymentMethodCharge = $paymentMethodCharge;

        $responseMessage = NULL;
        $responseMessage->AdditionalCharges = $additionalCharges;
        return $responseMessage;
    }

    function purchaseDone($onescanMessage) {
        $responseMessage = NULL;
        $orderAccepted = NULL;
        global $pluginPath;
        //	getting the task
        $y = new OnescanTaskManager();

        //	inilitialize onescan gateway
        include_once('OnescanPaymentGateway.php');


        $userToken = $onescanMessage->UserToken->UserToken;
        $firstName = $onescanMessage->PurchaseDetails->FirstName;
        $lastName = $onescanMessage->PurchaseDetails->LastName;
        $userEmail = $onescanMessage->PurchaseDetails->UserEmail;

        //	Delivery INformation
        $deliveryInfo = $onescanMessage->PurchaseDetails->DeliveryAddress;

        if (!isset($reponseMessage)) {
            $responseMessage = new stdClass;
        }
        if (!isset($orderAccepted)) {
            $orderAccepted = new stdClass;
        }


        $lastTask = $y->getTaskById($this->TaskId);

        //	Get User From if available
        $user_id = $lastTask->User;
        $user = get_user_by('id', $user_id);
        $address = null;


        $address = null;
        $order_data = null;
        if (isset($user->ID) & (intval($user->ID) != 0)) {
            $address = array(
                'first_name' => $user->first_name,
                'last_name' => $user->last_name,
                'company' => '',
                'email' => $user->user_email,
                'phone' => '',
                'address_1' => $deliveryInfo->AddressLine1,
                'address_2' => $deliveryInfo->AddressLine2,
                'city' => $deliveryInfo->Town,
                'state' => $deliveryInfo->State,
                'postcode' => $deliveryInfo->Postcode,
                'country' => $deliveryInfo->CountryCode
            );

            //	For Billing Address
            foreach ($address as $key => $value) {
                update_user_meta($user->ID, "billing_" . $key, $value);
            }

            //	For Shipping Address
            foreach ($address as $key => $value) {
                update_user_meta($user->ID, "shipping_" . $key, $value);
            }

            $order_data = array(
                'customer_id' => $user->ID
            );
        } else {
            // Guest Section
            // get user by Token
            $user = get_users(array('meta_key' => 'userToken', 'meta_value' => $lastTask->UserToken));
            if ($user[0]->ID == 0) {
                //	Register User
                $userDetails = array(
                    'LastName' => $lastName,
                    'FirstName' => $firstName,
                    'UserToken' => $lastTask->UserToken,
                    'UserEmail' => $userEmail,
                    'DeliveryInfo' => $deliveryInfo
                );

                $user_id = $this->registerUser($userDetails);
            } else {
                //	User exists and fetch the data relating to user token dtask
                $user_id = $user[0]->ID;
            };
            $user = get_user_by('ID', $user_id);
            $address = array(
                'first_name' => $user->first_name,
                'last_name' => $user->last_name,
                'company' => '',
                'email' => $user->user_email,
                'phone' => '',
                'address_1' => $deliveryInfo->AddressLine1,
                'address_2' => $deliveryInfo->AddressLine2,
                'city' => $deliveryInfo->Town,
                'state' => $deliveryInfo->State,
                'postcode' => $deliveryInfo->Postcode,
                'country' => $deliveryInfo->CountryCode
            );
            $order_data = array(
                'customer_id' => $user->ID
            );
        }

        //$totalAmount = $lastTask->Total;

        $order_id = $lastTask->OrderId;

        $order = wc_update_order(array('order_id' => $order_id, 'customer_id' => $user->ID));

        //	Sett Addresses
        $order->set_address($address, 'billing');
        $order->set_address($address, 'shipping');

        // Process Payment
        $av = new WC_Gateway_Onescan();
        $result = $av->process_payment($order_id);


        // Redirect to success/confirmation/payment page
        if ($result['result'] == 'success') {
            $result = apply_filters('woocommerce_payment_successful_result', $result, $order_id);
        }

        $y->updateTask(array(
            'Id' => $this->TaskId,
            'RedirectUrl' => $result['redirect'],
            'Error' => 'None',
            'Status' => 'Done'
        ));

        $orderAccepted->OrderId = $order_id;
        $responseMessage->OrderAccepted = $orderAccepted;
        $responseMessage->MessageType = "OrderAccepted";
        $responseMessage->Success = true;
        return $responseMessage;
    }

    function createSuccessMessage($onescanMessage) {
        $responseMessage = NULL;
        //	getting the task
        $y = new OnescanTaskManager();
        $MerchantTransactionId = $onescanMessage->PurchaseDetails->PurchaseInformation->MerchantTransactionId;
        $order_note = 'Onescan Payment Done.<br />Your Transaction Id is: ' . $MerchantTransactionId;

        $lastTask = $y->getTaskById($this->TaskId);

        //	Get User From if available
        $order_id = $lastTask->OrderId;
        $customer_note = 'Onescan payment completed. Reference is '.$order_id;
        $order = wc_update_order(array('order_id' => $order_id, 'customer_note' => $customer_note));
        $order->add_order_note($order_note, false, false);


        $responseMessage->Success = true;
        return $responseMessage;
    }

    function createWebContentMessage($onescanMessage) {
        $responseMessage = NULL;
        $webContent = NULL;
        $webContent->WebUrl = $webContentUrl;
        $webContent->ProcessCompleteUrl = "http://close-window";
        $field1->DataItem = "FirstName";
        $field1->HtmlId = "html_id_1";
        $webContent->FieldMappings[0] = $field1;
        $field2->DataItem = "LastName";
        $field2->HtmlId = "html_id_2";
        $webContent->FieldMappings[1] = $field2;
        $field3->DataItem = "Email";
        $field3->HtmlId = "html_id_3";
        $webContent->FieldMappings[2] = $field3;

        $responseMessage->WebContent = $webContent;
        return $responseMessage;
    }

    function createLoginMessage($onescanMessage, $taskManager) {
        //	Task
        $y = new OnescanTaskManager();

        $responseMessage = NULL;
        $processOutcome = NULL;

        // Task id
        $task = $taskManager->getCurrentTask();

        if (!isset($responseMessage)) {
            $responseMessage = new stdClass;
        }
        if (!isset($processOutcome)) {
            $processOutcome = new stdClass;
        }
        //TokenOrCredentials
        if ($onescanMessage->LoginPayload->LoginMode == 'Register') {
            $firstName = $onescanMessage->LoginCredentials->FirstName;
            $lastName = $onescanMessage->LoginCredentials->LastName;
            $userEmail = $onescanMessage->LoginCredentials->Email;
            $userToken = $onescanMessage->UserToken->UserToken;
            $userId = strtolower($firstName . $lastName) . rand(10, 100);


            //	Register User
            $userDetails = array(
                'LastName' => $lastName,
                'FirstName' => $firstName,
                'UserToken' => $userToken,
                'UserEmail' => $userEmail
            );

            $user = $this->registerUser($userDetails);


            if ($user != false) {
                $taskManager->updateTask(array(
                    'Id' => $this->TaskId,
                    'Error' => 'None',
                    'UserToken' => $userToken,
                    'RedirectURL' => get_site_url() // Home Page Url
                ));
            } else {
                $taskManager->updateTask(array(
                    'Id' => $this->TaskId,
                    'Error' => 'UserExists',
                    'UserToken' => $userToken,
                    'RedirectURL' => wp_login_url() // Home Page Url
                ));
            }
        }


        $responseMessage->MessageType = "ProcessComplete";
        $responseMessage->ProcessOutcome = $processOutcome;

        $responseMessage->Success = true;
        $processOutcome->RedirectURL = '';

        return $responseMessage;
    }

    function createStartLoginMessage($onescanMessage, $taskManager) {

        $responseMessage = NULL;
        $processOutcome = NULL;


        // Task id
        $task = $taskManager->getCurrentTask();

        if (!isset($responseMessage)) {
            $responseMessage = new stdClass;
        }
        if (!isset($processOutcome)) {
            $processOutcome = new stdClass;
        }
        if ($onescanMessage->ProcessType == 'Login') {
            $userToken = $onescanMessage->UserToken->UserToken;

            // Check if User Exists
            $user = get_users(array('meta_key' => 'userToken', 'meta_value' => $userToken));
            if (isset($user[0]) & ($user[0] != '')) {

                //echo 'asdf';
                $taskManager->updateTask(array(
                    'Id' => $this->TaskId,
                    'Error' => 'None',
                    'UserToken' => $userToken,
                    'RedirectURL' => get_site_url() // Home Page Url
                ));
            } else {
                //	Update the Task
                $taskManager->updateTask(array(
                    'Id' => $this->TaskId,
                    'Error' => 'UserNotExists',
                    'RedirectUrl' => wp_registration_url()
                ));
                //$responseMessage->MessageType = "ProcessComplete";
            }
        }
        $responseMessage->ProcessOutcome = $processOutcome;

        $responseMessage->Success = true;
        /*
          if (!isset($responseMessage->MessageType) || ($responseMessage->MessageType == '')) {
          $responseMessage->MessageType = "ProcessComplete";
          }
         * *
         */
        $responseMessage->MessageType = "ProcessComplete";

        return $responseMessage;
    }

    function hashit($message, $secret) {
        return hash_hmac('sha1', $message, $secret);
    }

}

?>