<?php
/*
 * Plugin Name: Onescan for wooCommerce
 * Plugin URI: http://www.ensygnia.com/
 * Description: Onescan is the breakthrough secure patented mobile transaction platform for the confidential exchange of personal and financial information brought to you by Ensygnia.
 * Version: 1.0.0
 * Author: Ensygnia
 * Author URI: http://www.ensygnia.com/
 * License: GPLv3 http://www.gnu.org/licenses/gpl-3.0-standalone.html
 * 
 * @package Onescan
 * @version 1.0.0
 * @author Ensygnia
*/

/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You can access a copy of the GNU General Public License
from the following http://www.gnu.org/licenses/gpl-3.0-standalone.html; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/


//ini_set('display_errors','on');
global $jsonContent;
$jsonContent = file_get_contents("php://input");



include_once('support/OnescanTasks.php');
include_once('onescanMain.php');


?>